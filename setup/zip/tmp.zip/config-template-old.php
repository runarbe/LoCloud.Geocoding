<?php

$conf = array();
$conf["app_title"] = "%s";
$conf["db"] = "%s";
$conf["db_host"] = "%s";
$conf["db_usr"] = "%s";
$conf["db_pwd"] = "%s";
$conf["basedir"] = dirname(__file__);
$conf["version"] = "1.2.7";
$conf["updateurl"] = "http://locloud.avinet.no/latest";
?>

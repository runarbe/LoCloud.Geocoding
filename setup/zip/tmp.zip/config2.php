<?php
class LgmsConfig {

    const app_title = "Geocoding Micro Service";
    const db = "locloud_test";
    const db_host = "localhost";
    const db_usr = "root";
    const db_pwd = "root";
    const basedir = "C:/Users/runarbe/Documents/Dropbox/70 - Private documents/Projects/Apache Root/locloudgc";
    const app_version = "1.2.10";
    const updateurl = "http://locloud.avinet.no/latest";

}


?>
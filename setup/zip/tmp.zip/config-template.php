<?php
class LgmsConfig {

    const app_title = "%s";
    const db = "%s";
    const db_host = "%s";
    const db_usr = "%s";
    const db_pwd = "%s";
    const basedir = "%s";
    const app_version = "1.2.11";
    const updateurl = "http://locloud.avinet.no/latest";

}


?>
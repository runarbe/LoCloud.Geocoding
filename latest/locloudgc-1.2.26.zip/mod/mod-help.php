<div id="dlgHelp" title="Help" class="ui-corner-all hidden">
</div>
<div id="dlgHelp" class="scrollable" title="Help" class="ui-corner-all hidden">
</div>
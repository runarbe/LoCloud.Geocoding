/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
function showImagePopup(pImageUrl) {
    var mImgHtml = "<img src=\"" + pImageUrl + "\"/>";
    jQuery("#dlgHelp").empty().html(mImgHtml);
    jQuery("#dlgHelp").dialog(
            {
                buttons: [
                    {
                        text: "Close",
                        click: function() {
                            jQuery("#dlgHelp").dialog("close");
                        }
                    }],
                hide: "fade",
                show: "fade",
                title: jsConf.app_title + " - Image Viewer",
                closeOnEscape: true,
                modal: true,
                height: 480,
                width: 640
            });

}
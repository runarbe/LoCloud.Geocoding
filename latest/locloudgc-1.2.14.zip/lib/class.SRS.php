<?php


/**
 * Description of class
 *
 * @author runarbe
 */
class SRS {
    function Add($pLabel, $pParams) {
        
    }
}
?>

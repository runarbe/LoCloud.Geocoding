<html>
    <body>
    <pre>
<?php
$pVersion = "2.2.2";
$mData = file_get_contents("config.php");
echo htmlentities($mData);

$mData = preg_replace('/conf\["version"\] = ".*"/', 'conf["version"] = "'.$pVersion.'"', $mData);
echo htmlentities($mData);

$pVersion = "3.2.1";

$mData = preg_replace('/conf\["version"\] = ".*"/', 'conf["version"] = "'.$pVersion.'"', $mData);
echo htmlentities($mData);

?>

</pre>
        
    </body>
    
</html>

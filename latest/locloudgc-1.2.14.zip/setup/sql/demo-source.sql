-- -------------------
-- Create test tables
-- -------------------

CREATE TABLE IF NOT EXISTS ds1 (
    id double DEFAULT NULL,
    title varchar(255) DEFAULT NULL,
    description varchar(255) DEFAULT NULL,
    country varchar(255) DEFAULT NULL,
    region varchar(255) DEFAULT NULL,
    `type` varchar(255) DEFAULT NULL,
    imageurl varchar(255) DEFAULT NULL,
    latitude double DEFAULT NULL,
    longitude double DEFAULT NULL,
    KEY idx_ds1_pk (id),
    KEY idx_ds1_adm0 (country),
    KEY idx_ds1_adm1 (region),
    KEY idx_ds1_cat (`type`)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS ds1_match (
    id int(11) NOT NULL AUTO_INCREMENT,
    fk_ds_id int(11) NOT NULL,
    gc_name varchar(512) DEFAULT NULL,
    gc_name2 varchar(512) DEFAULT NULL,
    gc_lon double NOT NULL,
    gc_lat double NOT NULL,
    gc_fieldchanges text,
    gc_geom text,
    gc_usr_id int(11) NOT NULL,
    gc_timestamp timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gc_probability int(11) NOT NULL,
    gc_dbsearch_id int(11) DEFAULT NULL,
    fk_db_id int(11) DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY idx_match_composite (fk_ds_id,gc_usr_id),
    KEY idx_match_fk_ds_id (fk_ds_id),
    KEY idx_match_gc_usr_id (gc_usr_id),
    KEY idx_match_gc_probability (gc_probability),
    KEY idx_match_fk_db_id (fk_db_id)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS ds1_adm0 (
    adm0 varchar(255) DEFAULT NULL,
    minx double DEFAULT NULL,
    miny double DEFAULT NULL,
    maxx double DEFAULT NULL,
    maxy double DEFAULT NULL
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS ds1_adm1 (
    adm0 varchar(255) DEFAULT NULL,
    adm1 varchar(255) DEFAULT NULL,
    minx double DEFAULT NULL,
    miny double DEFAULT NULL,
    maxx double DEFAULT NULL,
    maxy double DEFAULT NULL
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS ds1_cat (
    category varchar(255) DEFAULT NULL,
    minx double DEFAULT NULL,
    miny double DEFAULT NULL,
    maxx double DEFAULT NULL,
    maxy double DEFAULT NULL
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

-- ----------------
-- Insert demo data
-- ----------------

START TRANSACTION;
    INSERT INTO ds1 VALUES (1,'Stonehenge','The world\'s most famous prehistoric monument. People around the world consider it as a sacred site and they associate the ceremonial place with the super natural world.','United Kingdom','Wiltshire','Monument','http://www.nationsonline.org/gallery/Monuments/Stonehenge.jpg',51.1788,-1.8262);
    INSERT INTO ds1 VALUES (2,'Acropolis','The Acropolis of Athens can be seen as a symbol for the Ancient Greek World, the classical period of the Hellenic civilization.','Greece','Athens','Monument','http://www.nationsonline.org/gallery/Monuments/Acropolis_of_Athens.jpg',NULL,NULL);
    INSERT INTO ds1 VALUES (3,'Colosseum','The Flavian Amphitheater is an iconic symbol for Rome the \'Eternal City\' as well as for the civilization of the Imperial Roman Empire','Italy','Rome','Monument','http://www.nationsonline.org/gallery/Monuments/Colosseum_in_Rome.jpg',NULL,NULL);
    INSERT INTO ds1 VALUES (4,'Eiffel Tower','Few things symbolize Paris and France like this monument, it is the foremost universal icon of the French way of life of bon vivant and savoir vivre.','France','Paris','City icon','http://www.nationsonline.org/gallery/Monuments/Eiffel_Tower.jpg',48.8582,2.2945);
    INSERT INTO ds1 VALUES (5,'Big Ben','Clock Tower, Palace of Westminster, London,United Kingdom, is a symbol for London as well as an icon for the British way of life.','United Kingdom','London','City icon','http://www.nationsonline.org/gallery/Monuments/Big_Ben.jpg',NULL,NULL);
    INSERT INTO ds1 VALUES (6,'Leaning tower of Pisa','The Leaning Tower of Pisa is the result of a colossal miscalculation. Everyone makes mistakes, but most people\'s mistakes does not weigh 14,500 tonnes. But some mistakes are excusable, after a while. ','Italy','Pisa','City icon','http://www.nationsonline.org/gallery/Monuments/Leaning_Tower_of_Pisa.jpg',NULL,NULL);
    INSERT INTO ds1 VALUES (7,'Cologne Cathedral','The Cologne Cathedral is the largest Gothic church in northern Europe and the dominant landmark of the city of Cologne.','Germany','Cologne','City icon','http://www.nationsonline.org/gallery/Monuments/Cologne_Cathedral.jpg',NULL,NULL);
    INSERT INTO ds1 VALUES (8,'Brandenburg Gate','Main symbol of Berlin and today also a symbol for the reunited Germany.','Germany','Berlin','City icon','http://www.nationsonline.org/gallery/Monuments/Brandenburger_Tor.jpg',NULL,NULL);
    INSERT INTO ds1 VALUES (9,'Hagia Sophia','A former patriarchal basilica, the largest cathedral in the world for nearly a thousand years. In 1453, Constantinople (today Istanbul) was conquered by the Ottoman Turks and Sultan Mehmed II ordered the building to be converted into a mosque.','Turkey','Istanbul','Place of worship','http://www.nationsonline.org/gallery/Monuments/Hagia-Sophia.jpg',NULL,NULL);
    INSERT INTO ds1 VALUES (10,'Basilica of St Peter','One of the symbols and focal points for the Catholic faith, part of Vatican City, the papal residence. ','Vatican','Vatican City','Place of worship','http://www.nationsonline.org/gallery/Monuments/St-Peter-Holy-Sea.jpg',NULL,NULL);
    INSERT INTO ds1 VALUES (11,'Schönbrunn Palace','The palace was one of the residences of the Habsburg empire in','Austria','Vienna','Palace','http://www.nationsonline.org/gallery/Monuments/Schloss_Schoenbrunn.jpg',NULL,NULL);
    INSERT INTO ds1 VALUES (12,'Palace of Versailles (Château de Versailles)','The royal chateau was built by the Sun King Louis XIV, it was (and still is) a symbol of absolute monarchy expressed in stone and environment.','France','Paris','Palace','http://www.nationsonline.org/gallery/Monuments/Versailles_Palace.jpg',NULL,NULL);
COMMIT;

START TRANSACTION;
    INSERT INTO ds1_cat VALUES ('City icon',2.2945,48.8582,2.2945,48.8582);
    INSERT INTO ds1_cat VALUES ('Monument',-1.8262,51.1788,-1.8262,51.1788);
    INSERT INTO ds1_cat VALUES ('Palace',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_cat VALUES ('Place of worship',NULL,NULL,NULL,NULL);
COMMIT;

START TRANSACTION;
    INSERT INTO `meta_usr` (`id`, `usr`, `pwd`, `level`) VALUES (NULL, 'admin', 'admin', 1);
    INSERT INTO `meta_usr` (`id`, `usr`, `pwd`, `level`) VALUES (NULL, 'user', 'user', 6);
    INSERT INTO `meta_usr` (`id`, `usr`, `pwd`, `level`) VALUES (NULL, 'guest', 'guest', 99);
COMMIT;

START TRANSACTION;
    INSERT INTO meta_datasources VALUES (1,'Test dataset','id','title','longitude','latitude','4326','ds1','type','country','region',7,'imageurl');
    INSERT INTO meta_dbsearch VALUES (1,'European cities > 100k','sch_geonames_eu100k','name','admin1 code','admin2 code','admin3 code',4326,'longitude','latitude','name;asciiname;alternatenames',NULL,'ws-search-geonames');
COMMIT;

START TRANSACTION;
    INSERT INTO ds1_adm1 VALUES ('Austria','Vienna',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm1 VALUES ('France','Paris',2.2945,48.8582,2.2945,48.8582);
    INSERT INTO ds1_adm1 VALUES ('Germany','Berlin',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm1 VALUES ('Germany','Cologne',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm1 VALUES ('Greece','Athens',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm1 VALUES ('Italy','Pisa',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm1 VALUES ('Italy','Rome',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm1 VALUES ('Turkey','Istanbul',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm1 VALUES ('United Kingdom','London',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm1 VALUES ('United Kingdom','Wiltshire',-1.8262,51.1788,-1.8262,51.1788);
    INSERT INTO ds1_adm1 VALUES ('Vatican','Vatican City',NULL,NULL,NULL,NULL);
COMMIT;

START TRANSACTION;
    INSERT INTO ds1_adm0 VALUES ('Austria',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm0 VALUES ('France',2.2945,48.8582,2.2945,48.8582);
    INSERT INTO ds1_adm0 VALUES ('Germany',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm0 VALUES ('Greece',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm0 VALUES ('Italy',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm0 VALUES ('Turkey',NULL,NULL,NULL,NULL);
    INSERT INTO ds1_adm0 VALUES ('United Kingdom',-1.8262,51.1788,-1.8262,51.1788);
    INSERT INTO ds1_adm0 VALUES ('Vatican',NULL,NULL,NULL,NULL);
COMMIT;
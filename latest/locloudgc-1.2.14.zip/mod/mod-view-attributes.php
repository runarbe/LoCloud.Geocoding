<div id="dlgViewAttributes" title="View/edit source item attributes" class="ui-corner-all hidden wide">
    <p>The below table shows the attributes of the selected source item.</p>
    <form id="editableAttributes">
        <table id="attributeTable" class="wide">
        </table>
        <a id="btnCancelEditsClose" class="attribFormBtn" href="#">Close without saving</a>
        <a id="btnSaveAttrEdits" class="attribFormBtn" href="#">Save attribute edits</a>
    </form>
</div>
<?php
/**
 * Possible data types for text file fields
 */
class TextFileDataType {
    const Integer = "integer";
    const Decimal = "double";
    const String = "varchar(250)";
    const Boolean = "bool";
}

?>

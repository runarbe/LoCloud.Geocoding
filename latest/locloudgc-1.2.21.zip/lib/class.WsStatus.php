<?php

/**
 * Enumeration class with constants for status messages
 */
class WsStatus {

    const success = 1;
    const failure = -1;

}
?>

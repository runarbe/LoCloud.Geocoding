<form id="statusBar">
    <!--table id="sBarTable">
        <tr>
            <td>
                <input type="text" id="leftPane"/>
            </td>
            <td>
                <input type="text" id="rightPane"/>
            </td>
        </tr>
    </table-->

    <p class="label"><a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_US"><img alt="Creative Commons License" style="border-width:0; horizontal-align: left; vertical-align: middle;" src="http://i.creativecommons.org/l/by-nc-sa/3.0/80x15.png"/></a>&nbsp;<span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/InteractiveResource" property="dct:title" rel="dct:type">LoCloud Geocoding Application  v<?php echo LgmsConfig::app_version; ?></span> by <a xmlns:cc="http://creativecommons.org/ns#" href="http://www.avinet.no" property="cc:attributionName" rel="cc:attributionURL">AVINET (SRB)</a> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_US">Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License</a>.</p>
</form>
<?php

//Add dependencies
require_once("TextFileErrorMsg.class.php");
require_once("FieldDef.class.php");
require_once("FieldDefSet.class.php");
require_once("TextFileDataType.class.php");
require_once("TextFileSepChar.class.php");
require_once("TextFileType.class.php");

//Add at end
require_once("TextFileParser.class.php");

?>

<?php
require('../functions.php');

$r = new WsRetObj();

$mParams = array(
    "fn" => new WsParamOptions(true),
    "delimiter" => new WsParamOptions(true, null, "\t")
);

checkWsParameters($mParams, $r);

$mParams["fn"] = "../upload/" . $mParams["fn"];

if (!file_exists($mParams["fn"])) {
    $r->v = WsStatus::failure;
    $r->addMsg("File doesn't exist", $mParams["fn"]);
}

if ($r->v == WsStatus::failure) {
    echo $r->getResult();
} else {
    $mCsvParser = new CsvParser($mParams["fn"], db());
    
    $mCsvParser->parseData();
    
    if (!$mCsvParser->createTable()) {
        $r->setFailure("Could not create table");
    }
    while ($mCsvParser->insertChunk());
    $r->addData($mCsvParser->fields, "fields");
    $r->addData($mCsvParser->tmpName, "table");
    unlink($mParams["fn"]);
    echo $r->getResult();
}
?>
<?php

/**
 * User levels
 */
class WsUserLevel {

    const SuperAdmin = 1;
    const Admin = 2;
    const Editor = 4;
    const User = 6;
    const GuestUser = 99;

}
?>

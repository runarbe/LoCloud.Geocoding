function clearSourceItemListSelection() {
    jQuery("#selectable li").removeClass("ui-state-highlight");
    jQuery("#selectable li").removeClass("ui-selected");
    return true;
}

function loadCategories(pDatasourceId){
    var currentCatTable = "ds"+pDatasourceId+"_cat";
    jQuery.getJSON("./ws/ws-cat.php",
    {
        t:currentCatTable
    },
    function(data){
        /*
         * Reset category filter
         */
        jQuery("#sbFilterCategory").empty();
        var opt = jQuery("<option></option>");
        opt.html("all categories");
        opt.val("");
        jQuery("#sbFilterCategory").append(opt);
        
        if (data.s == 1) {
            if (data.d.length > 0) {
                jQuery("#frmFilterByCategory").show();
                /*
                 * Add options to #sbFilterCategory control
                 */
                jQuery.each(data.d, function(key, val) {
                    var opt = jQuery("<option></option>");
                    opt.html(val.category);
                    opt.val(val.category);
                    opt.data("attributes",val);
                    jQuery("#sbFilterCategory").append(opt);
                });                            
            } else {
                console.log("No categories: " + data);
            }
        } else {
            showMsgBox(data.m, true);
        }
    });
}

function loadAdm0(pDatasourceId){
    var currentAdm0Table = "ds"+pDatasourceId+"_adm0";
    jQuery.getJSON("./ws/ws-adm0.php",
    {
        t:currentAdm0Table
    },
    function(data){
        /*
         * Reset adm1 filter
         */
        jQuery("#sbFilterAdm0").empty();
        var opt = jQuery("<option></option>");
        opt.html("all areas");
        opt.val("");
        jQuery("#sbFilterAdm0").append(opt);
        
        if (data.s == 1) {
            if (data.d.length == 0) {
                console.log("No adm1 areas: " + data);
            } else {
                jQuery("#frmFilterByArea").show();
                jQuery("#sbFilterAdm0").show();
                /*
                 * Add options to adm0
                 */
                jQuery.each(data.d, function(key, val) {
                    var opt = jQuery("<option></option>");
                    opt.html(val.adm0);
                    opt.val(val.adm0);
                    opt.data("attributes",val);
                    jQuery("#sbFilterAdm0").append(opt);
                });                            
            }
        } else {
            console.log("Error loading adm0 areas: " + data.m);
        }
    });
}

function loadAdm1(pDatasourceId, pCurrentAdm0){
    /*
     * Construct adm0 table name based on id of datasource
     */
    var currentAdm0Table = "ds"+pDatasourceId+"_adm1";
    
    /*
     * Issue ajax request
     */
    jQuery.getJSON("./ws/ws-adm1.php",
    {
        t:currentAdm0Table,
        a0:pCurrentAdm0
    },
    function(data){
        /*
         * Reset adm1 filter
         */
        jQuery("#sbFilterAdm1").empty();
        var opt = jQuery("<option></option>");
        opt.html("all areas");
        opt.val("");
        jQuery("#sbFilterAdm1").append(opt);
        
        if (data.s == 1) {
            if (data.d.length == 0) {
                console.log("Notice no adm1 areas: "+ data);
            } else {
                jQuery("#sbFilterAdm1").show();
                
                /*
                 * Add options to adm1 dropdown
                 */
                jQuery.each(data.d, function(key, val) {
                    var opt = jQuery("<option></option>");
                    opt.html(val.adm1);
                    opt.val(val.adm1);
                    opt.data("attributes",val);
                    jQuery("#sbFilterAdm1").append(opt);
                });                            
            }
        } else {
            console.log("Error loading adm1 areas: " + data.m);
        }
    });
}

function loadDatasources(pDatasourceId){
    
    jQuery.getJSON("./ws/ws-load-datasources.php",
    {
        id:pDatasourceId
    },
    function(data){
        if (data.s === 1) {
            if (data.d.length === 0) {
                //console.log(data);
            } else {
                jQuery.each(data.d, function(key, val) {
                    var opt = jQuery("<option></option>");
                    opt.html(val.ds_title);
                    opt.val(val.id);
                    opt.data("attributes",val);
                    jQuery("#sbDatasource").append(opt);
                });                            
            }
        } else {
            console.log(data.m);
        }
    }).fail(function() {
        showMsgBox(new Array("Could not load datasources"), true);
    });
}

function getSelectedSourceItem() {
    return jQuery(".ui-selected", "#selectable").first();
}

function getSelectedDatasource() {
    return jQuery("#sbDatasource option:selected").data("attributes");
}

function clearSourceItemList() {
    jQuery('#selectable').html("");
}

function loadSourceItems2 (pOffset, pLimit) {
    
    var a0 = jQuery("#sbFilterAdm0").val();
    var a1 = jQuery("#sbFilterAdm1").val();
    var p = jQuery("#sbFilterProbability").val();
    var c = jQuery("#sbFilterCategory").val();
    var dsID = getSelectedDatasource().id;
    jQuery.getJSON('./ws/ws-load-source-items3.php',
    {
        t:mDatasource.ds_table,
        dsID:dsID,
        idc:mDatasource.ds_col_pk,
        nc:mDatasource.ds_col_name,
        xc:mDatasource.ds_col_x,
        yc:mDatasource.ds_col_y,
        a0_c:mDatasource.ds_col_adm0,
        a0:a0,
        p:p,
        a1_c:mDatasource.ds_col_adm1,
        a1:a1,
        c_c:mDatasource.ds_col_cat,
        c:c,
        offset:pOffset,
        limit:pLimit
    },
    /**
     * @param {WsRetObj} data
     * @ignore
     */
    function(data) {
        if (data.v === WsStatus.success) {
            //console.log(data);
            clearSourceItemList();
            jQuery.each(data.d,function(key, val) {
                /*
                 * Create new list item and assign default value if empty
                 */
                var listElement = jQuery('<li></li>');
                if (jQuery.trim(val._nc) == '') {
                    val._nc = 'Item #' + val._id;
                }
                listElement.html(val._nc);

                if (val.gc_probability != null) {
                    listElement.addClass("prob"+val.gc_probability);
                }
                listElement.addClass("ui-state-default");
                listElement.data("attributes", val)
                jQuery('#selectable').append(listElement);                
            });
            /*
             * If the load source item does not yield any results, provide this notification.
             */
            if (data.d.length == 0) {
                var mNotification = jQuery("<div></div>");
                mNotification.addClass("ui-state-highlight");
                mNotification.text("You have completed all the items in the current selection or the current filters you have selected above excludes all items.");
                jQuery('#selectable').append(mNotification);                                
            }

            if (listSrcDataStartItem == 0) {
                jQuery("#btnPrevSrc").button("option", "disabled", true);
            } else {
                jQuery("#btnPrevSrc").button("option", "disabled", false);
            }
            if (data.d.length < listSrcDataNumItems) {
                jQuery("#btnNextSrc").button("option", "disabled", true);                    
            } else {
                jQuery("#btnNextSrc").button("option", "disabled", false);                 
            }
        }
        else {
            showMsgBox(data.m, true);
        }
    }).fail(function(jqXHR, textStatus, errorThrown) {
        showMsgBox(new Array(textStatus, errorThrown), false);
    });
}
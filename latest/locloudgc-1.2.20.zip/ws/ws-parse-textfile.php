<?php

require('../functions.php');

$r = new WsRetObj();

$mParams = array(
    "fn" => new WsParamOptions(true),
    "delimiter" => new WsParamOptions(true),
    "fnfirstrow" => new WsParamOptions(true),
    "encoding" => new WsParamOptions(true)
);

checkWsParameters($mParams, $r);

// Add upload path to filename
$mParams["fn"] = "../upload/" . $mParams["fn"];

if (!file_exists($mParams["fn"])) {
    $r->v = WsStatus::failure;
    $r->addMsg("File doesn't exist", $mParams["fn"]);
}

if ($r->v == WsStatus::failure) {
    echo $r->getResult();
} else {
    $mCsvParser = new CsvParser($mParams["fn"], db());
    $mCsvParser->setDelimiter($mParams["delimiter"]);
    if ($mParams["fnfirstrow"] === "true") {
        $mCsvParser->firstRowFieldNames = true;
    } else {
        $mCsvParser->firstRowFieldNames = false;
    }
    $mCsvParser->sourceEncoding = $mParams["encoding"];

    $mCsvParser->parseData();

    if (!$mCsvParser->createTable()) {
        $r->setFailure("Could not create table");
    }
    while ($mCsvParser->insertChunk());
    $r->addData($mCsvParser->fields, "fields");
    $r->addData($mCsvParser->tmpName, "table");
    unlink($mParams["fn"]);
    echo $r->getResult();
}
?>
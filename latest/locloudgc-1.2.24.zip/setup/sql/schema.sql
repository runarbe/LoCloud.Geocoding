CREATE TABLE IF NOT EXISTS meta_usr (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `usr` VARCHAR(10) NOT NULL ,
  `pwd` VARCHAR(10) NOT NULL ,
  `level` INT(11) NOT NULL DEFAULT '5' ,
  PRIMARY KEY (`id`) ,
  UNIQUE INDEX `idx_usr_usr` (`usr` ASC) )
ENGINE = InnoDB
AUTO_INCREMENT = 6
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS meta_uploads (
  id int(11) NOT NULL AUTO_INCREMENT,
  fk_meta_usr_id int(11) NOT NULL,
  fname varchar(512) NOT NULL,
  tstamp timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8

CREATE TABLE IF NOT EXISTS meta_datasources (
  id int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier',
  ds_title varchar(50) NOT NULL COMMENT 'Name of a column in the source dataset that contains titles of items to be geocoded',
  ds_col_pk varchar(50) NOT NULL COMMENT 'Name of a column in the source dataset that contains a unique identifier for each record',
  ds_col_name varchar(50) NOT NULL,
  ds_col_x varchar(50) DEFAULT NULL,
  ds_col_y varchar(50) DEFAULT NULL,
  ds_srs varchar(50) NOT NULL,
  ds_table varchar(50) NOT NULL,
  ds_col_cat varchar(50) DEFAULT NULL,
  ds_col_adm0 varchar(50) DEFAULT NULL,
  ds_col_adm1 varchar(50) DEFAULT NULL,
  ds_coord_prec int(11) DEFAULT NULL,
  ds_col_image varchar(50) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY id_UNIQUE (id)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE  meta_datasources ADD COLUMN ds_col_url VARCHAR(50) NULL  AFTER ds_col_image , ADD COLUMN ds_tstamp TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP AFTER ds_col_url;

CREATE TABLE IF NOT EXISTS meta_usr_ds (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `fk_meta_datasources_id` INT(11) NOT NULL ,
  `fk_meta_usr_id` INT(11) NOT NULL ,
  `access` INT(11) NOT NULL DEFAULT '1' COMMENT '1 = owner\n2 = editor\n3 = viewer' ,
  PRIMARY KEY (`id`) ,
  INDEX `idx_meta_usr_ds_fk_ds_id` (`fk_meta_datasources_id` ASC) ,
  INDEX `idx_meta_usr_ds_fk_usr_id` (`fk_meta_usr_id` ASC) ,
  INDEX `fk_meta_datasources_id` (`fk_meta_datasources_id` ASC) ,
  INDEX `fk_meta_usr_id` (`fk_meta_usr_id` ASC) ,
  CONSTRAINT `fk_meta_datasources_id`
    FOREIGN KEY (`fk_meta_datasources_id` )
    REFERENCES `meta_datasources` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_meta_usr_id`
    FOREIGN KEY (`fk_meta_usr_id` )
    REFERENCES `meta_usr` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS meta_dbsearch (
  id int(11) NOT NULL AUTO_INCREMENT,
  sch_title varchar(45) DEFAULT NULL,
  sch_table varchar(45) DEFAULT NULL,
  sch_display varchar(200) DEFAULT NULL,
  sch_lev1 varchar(200) DEFAULT NULL,
  sch_lev2 varchar(200) DEFAULT NULL,
  sch_lev3 varchar(200) DEFAULT NULL,
  sch_epsg int(11) DEFAULT NULL,
  sch_lon varchar(200) DEFAULT NULL,
  sch_lat varchar(200) DEFAULT NULL,
  sch_like varchar(200) DEFAULT NULL,
  sch_eq varchar(200) DEFAULT NULL,
  sch_webservice varchar(200) DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS meta_match_template (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `fk_ds_id` INT(11) NOT NULL ,
  `gc_name` VARCHAR(512) NULL DEFAULT NULL ,
  `gc_name2` VARCHAR(512) NULL DEFAULT NULL ,
  `gc_lon` DOUBLE NOT NULL ,
  `gc_lat` DOUBLE NOT NULL ,
  `gc_fieldchanges` TEXT NULL DEFAULT NULL ,
  `gc_geom` TEXT NULL DEFAULT NULL ,
  `gc_usr_id` INT(11) NOT NULL ,
  `gc_timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
  `gc_probability` INT(11) NOT NULL ,
  `gc_dbsearch_id` INT(11) NULL DEFAULT NULL ,
  `fk_db_id` INT(11) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) ,
  UNIQUE INDEX `idx_match_composite` (`fk_ds_id` ASC, `gc_usr_id` ASC) ,
  INDEX `idx_match_fk_ds_id` (`fk_ds_id` ASC) ,
  INDEX `idx_match_gc_usr_id` (`gc_usr_id` ASC) ,
  INDEX `idx_match_gc_probability` (`gc_probability` ASC) ,
  INDEX `idx_match_fk_db_id` (`fk_db_id` ASC) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `sch_geonames_template` (
  `geonameid` INT(11) NULL DEFAULT NULL ,
  `name` VARCHAR(200) NULL DEFAULT NULL ,
  `asciiname` VARCHAR(200) NULL DEFAULT NULL ,
  `alternatenames` MEDIUMTEXT NULL DEFAULT NULL ,
  `latitude` DOUBLE NULL DEFAULT NULL ,
  `longitude` DOUBLE NULL DEFAULT NULL ,
  `feature class` VARCHAR(1) NULL DEFAULT NULL ,
  `feature code` VARCHAR(10) NULL DEFAULT NULL ,
  `country code` VARCHAR(2) NULL DEFAULT NULL ,
  `cc2` VARCHAR(60) NULL DEFAULT NULL ,
  `admin1 code` VARCHAR(20) NULL DEFAULT NULL ,
  `admin2 code` VARCHAR(80) NULL DEFAULT NULL ,
  `admin3 code` VARCHAR(20) NULL DEFAULT NULL ,
  `admin4 code` VARCHAR(20) NULL DEFAULT NULL ,
  `population` INT(11) NULL DEFAULT NULL ,
  `elevation` SMALLINT(6) NULL DEFAULT NULL ,
  `dem` DOUBLE NULL DEFAULT NULL ,
  `timezone` VARCHAR(40) NULL DEFAULT NULL ,
  `modification date` DATETIME NULL DEFAULT NULL )
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `meta_srs` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL ,
  `values` TEXT NOT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;
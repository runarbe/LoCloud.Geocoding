<?php
require_once("../functions.php");
dieIfSessionExpired();

$m = array(); //Mesages, notices, errors
$v = 1; //Return status 1=success,-1=error
$r = array();

$mDb = db();
if (!is_numeric($_GET["id"])) {
  $mSql = "SELECT * FROM meta_datasources ORDER BY ds_title ASC";  
  $m[] = "Notice: no datasource id specified.";
} else {
  $mSql = "SELECT * FROM meta_datasources WHERE id = ".$_GET["id"]." ORDER BY ds_title ASC";
}

if ($result = $mDb->query($mSql)) {
    $r["s"] = 1;
    $r["d"] = array();
    while($obj = $result->fetch_object()) {
        $r["d"][] = $obj;
    };
    $result->close();
} else {
    $r["s"] = -1;
    $m[] = $mSql;
    $m[] = mysqli_error($mDb);
}

$r["m"] = $m;
dbc($mDb);
echo json_encode($r);
?>